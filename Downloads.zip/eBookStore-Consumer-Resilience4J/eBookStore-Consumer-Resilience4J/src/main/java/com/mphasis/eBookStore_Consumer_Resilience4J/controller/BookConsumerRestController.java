package com.mphasis.eBookStore_Consumer_Resilience4J.controller;

import com.mphasis.eBookStore_Consumer_Resilience4J.service.BookService;
import com.mphasis.eBookStore_Consumer_Resilience4J.model.Book;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BookConsumerRestController {

    @Autowired
    private BookService bookService;

    // Endpoint to fetch a book by ID
    @GetMapping("/books/{id}")
    public Book getBookById(@PathVariable Long id) {
        return bookService.getBookById(id);
    }

    // Optional endpoint to get all books (if you have a method in BookService)
    @GetMapping("/books")
    public List<Book> getBooks() {
        return bookService.getBooks();
    }
}
