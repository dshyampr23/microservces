package com.mphasis.eBookStore_Consumer_Resilience4J.service;

import com.mphasis.eBookStore_Consumer_Resilience4J.model.Book;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Collections;

@Service
public class BookService {

    private final String BOOK_API_URL = "http://bookstore-api.com/books"; // Replace with actual API URL
    private final String BOOK_BY_ID_API_URL = "http://bookstore-api.com/books/{id}"; // Endpoint to get a book by ID

    @Autowired
    private RestTemplate restTemplate;

    // Fallback method to handle failures for fetching book by ID
    public Book fallbackForGetBookById(Long bookId, Exception e) {
        // Fallback logic: return a default Book when the service is down
        return new Book("Fallback Book", "Fallback Author", "0000");
    }

    // Main method to get book by ID, annotated with @CircuitBreaker
    @Retry(name = "book-service")
    @CircuitBreaker(name = "book-service", fallbackMethod = "fallbackForGetBookById")
    public Book getBookById(Long bookId) {
        // Calling the external API using RestTemplate to fetch the book by ID
        ResponseEntity<Book> response = restTemplate.getForEntity(BOOK_BY_ID_API_URL, Book.class, bookId);
        return response.getBody();
    }

    // Method to get all books (example)
    public List<Book> getBooks() {
        try {
            ResponseEntity<List> response = restTemplate.getForEntity(BOOK_API_URL, List.class);
            return response.getBody();
        } catch (Exception e) {
            // Handle exception (could also use fallback here if needed)
            return Collections.emptyList();
        }
    }
}
