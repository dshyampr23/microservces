package com.mphasis.eBookStore_Consumer_Resilience4J;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreConsumerResilience4JApplicationTests {

	@Test
	void contextLoads() {
	}

}
