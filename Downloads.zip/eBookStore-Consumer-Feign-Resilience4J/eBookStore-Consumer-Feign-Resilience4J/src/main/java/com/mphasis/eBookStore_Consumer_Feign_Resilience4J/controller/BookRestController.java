package com.mphasis.eBookStore_Consumer_Feign_Resilience4J.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.mphasis.eBookStore_Consumer_Feign_Resilience4J.model.Book;
import com.mphasis.eBookStore_Consumer_Feign_Resilience4J.proxy.BookServiceProxy;

import java.util.List;

@RestController
@RequestMapping("/api/books")
public class BookRestController {

    private final BookServiceProxy bookServiceProxy;

    // Autowire the BookServiceProxy (Feign client)
    @Autowired
    public BookRestController(BookServiceProxy bookServiceProxy) {
        this.bookServiceProxy = bookServiceProxy;
    }

    // Get all books
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = bookServiceProxy.getAllBooks();
        if (books.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);  // If no books found, return HTTP 204
        }
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    // Get book by ID
    @GetMapping("/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable("id") Long id) {
        Book book = bookServiceProxy.getBookById(id);
        if (book == null || book.getId() == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);  // If book not found, return HTTP 404
        }
        return new ResponseEntity<>(book, HttpStatus.OK);
    }

    // Create a new book
    @PostMapping
    public ResponseEntity<Book> createBook(@RequestBody Book book) {
        Book createdBook = bookServiceProxy.addBook(book);
        return new ResponseEntity<>(createdBook, HttpStatus.CREATED);  // Return HTTP 201
    }

    // Update an existing book
    @PutMapping("/{id}")
    public ResponseEntity<Book> updateBook(@PathVariable("id") Long id, @RequestBody Book book) {
        Book updatedBook = bookServiceProxy.updateBook(id, book);
        if (updatedBook == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);  // Return HTTP 404 if not found
        }
        return new ResponseEntity<>(updatedBook, HttpStatus.OK);
    }

    // Delete a book by ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBook(@PathVariable("id") Long id) {
        try {
            bookServiceProxy.deleteBook(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);  // Return HTTP 204 if successful
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);  // Return HTTP 404 if book not found
        }
    }
}
