package com.mphasis.eBookStore_Consumer_Feign_Resilience4J.proxy;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

import com.mphasis.eBookStore_Consumer_Feign_Resilience4J.model.Book;


@Component  // Annotate the fallback class with @Component
public class BookServiceFallback implements BookServiceProxy {

    @Override
    public List<Book> getAllBooks() {
        // Return an empty list or some default value in case of failure
        return Collections.emptyList();  
    }

    @Override
    public Book getBookById(Long id) {
        // Return a default book or handle the case appropriately when service is down
        return new Book(id, "Unavailable", "Unknown", 0.0);
    }

    @Override
    public Book addBook(Book book) {
        // Return a default or empty book as a fallback
        return new Book(0L, "Fallback Book", "Unknown", 0.0);
    }

    @Override
    public Book updateBook(Long id, Book book) {
        // Handle update failure scenario, maybe return a default book
        return new Book(id, "Fallback Book", "Unknown", 0.0);
    }

    @Override
    public void deleteBook(Long id) {
        // Perform a no-op if the service is down
        System.out.println("Delete operation failed, no book found with id " + id);
    }
}
