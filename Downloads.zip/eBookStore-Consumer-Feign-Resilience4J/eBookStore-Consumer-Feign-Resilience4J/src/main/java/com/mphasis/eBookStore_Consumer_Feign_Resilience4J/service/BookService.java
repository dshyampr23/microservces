package com.mphasis.eBookStore_Consumer_Feign_Resilience4J.service;

public class BookService {

}
