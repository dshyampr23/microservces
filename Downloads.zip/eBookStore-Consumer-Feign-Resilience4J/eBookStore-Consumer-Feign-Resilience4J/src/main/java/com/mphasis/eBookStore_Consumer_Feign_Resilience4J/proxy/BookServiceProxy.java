package com.mphasis.eBookStore_Consumer_Feign_Resilience4J.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.mphasis.eBookStore_Consumer_Feign_Resilience4J.model.Book;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import io.github.resilience4j.retry.annotation.Retry;

@FeignClient(name = "book-service", fallback = BookServiceFallback.class)
public interface BookServiceProxy {
	
	@Retry(name="book-service")
	@CircuitBreaker(name="book-service", fallbackMethod="fallbackMethodGetAllBooks")
    @GetMapping(value="/books", produces={MediaType.APPLICATION_JSON_VALUE})
    List<Book> getAllBooks();
	
	@Retry(name="book-service")
	@CircuitBreaker(name="book-service", fallbackMethod="fallbackMethodGetBookById")
    @GetMapping(value="/books/{id}", produces={MediaType.APPLICATION_JSON_VALUE})
    Book getBookById(@PathVariable("id") Long id);

    @PostMapping("/books")
    Book addBook(@RequestBody Book book);

    @PutMapping("/books/{id}")
    Book updateBook(@PathVariable("id") Long id, @RequestBody Book book);

    @DeleteMapping("/books/{id}")
    void deleteBook(@PathVariable("id") Long id);
}