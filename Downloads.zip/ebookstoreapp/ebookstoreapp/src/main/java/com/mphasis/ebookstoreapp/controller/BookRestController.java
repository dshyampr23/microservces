package com.mphasis.ebookstoreapp.controller;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
 
import com.mphasis.ebookstoreapp.entity.Book;
import com.mphasis.ebookstoreapp.service.BookService;
 
import java.util.List;
import java.util.Optional;
 
@RestController
@RequestMapping("/books")
public class BookRestController {
 
    @Autowired
    private BookService bookService;
 
    // Add book details
    @PostMapping
    public ResponseEntity<Book> addBook(@RequestBody Book book) {
        Book addedBook = bookService.addBook(book);
        return new ResponseEntity<>(addedBook, HttpStatus.CREATED);
    }
 
    // Update book details
    @PutMapping
    public ResponseEntity<Book> updateBook(@RequestBody Book book) {
        Book updatedBook = bookService.updateBook(book);
        return new ResponseEntity<>(updatedBook, HttpStatus.OK);
    }
 
    // Get all books details
    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = bookService.findAllBooks();
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
 
    // Get single book by ID
    @GetMapping("/books/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable("id") Long id) {
        Optional<Book> book = bookService.findBookById(id);
        return book.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                   .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }
 
    // Delete book by ID
    @DeleteMapping("/{book_id}")
    public ResponseEntity<Void> deleteBookById(@PathVariable("book_id") Long id) {
    	bookService.deleteBookById(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
 
    // Find books by title
    @GetMapping("/title/{book_title}")
    public ResponseEntity<List<Book>> getBooksByTitle(@PathVariable("book_title") String title) {
        List<Book> books = bookService.findByBookTitle(title);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
 
    // Find books by publisher
    @GetMapping("/publisher/{book_publisher}")
    public ResponseEntity<List<Book>> getBooksByPublisher(@PathVariable("book_publisher") String publisher) {
        List<Book> books = bookService.findByBookPublisherLike(publisher);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
 
    // Find books by year
    @GetMapping(params = "year")
    public ResponseEntity<List<Book>> getBooksByYear(@RequestParam("year") Integer year) {
        List<Book> books = bookService.findByBookYear(year);
        return new ResponseEntity<>(books, HttpStatus.OK);
    }
}