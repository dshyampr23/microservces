package com.mphasis.ebookstoreapp.service;
 
import java.util.List;
import java.util.Optional;
 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
 
import com.mphasis.ebookstoreapp.entity.Book;
import com.mphasis.ebookstoreapp.repository.BookRepository;
 
@Service
public class BookServiceImpl implements BookService {
	@Autowired
    private BookRepository bookRepository;
 
    // Add book details
    public Book addBook(Book book) {
        return bookRepository.save(book);
    }
 
    // Update book details
    public Book updateBook(Book book) {
        return bookRepository.save(book);
    }
 
    // Find all books
    public List<Book> findAllBooks() {
        return bookRepository.findAll();
    }
 
    // Find book by ID
    public Optional<Book> findBookById(Long id) {
        return bookRepository.findById(id);
    }
 
    // Delete book by ID
    public void deleteBookById(Long id) {
    	bookRepository.deleteById(id);
    }
 
    // Custom query methods
    public List<Book> findByBookTitle(String title) {
        return bookRepository.findByBookTitle(title);
    }
 
    public List<Book> findByBookPublisherLike(String publisher) {
        return bookRepository.findByBookPublisherLike(publisher);
    }
 
    public List<Book> findByBookYear(Integer year) {
        return bookRepository.findByBookYear(year);
    }
 
}