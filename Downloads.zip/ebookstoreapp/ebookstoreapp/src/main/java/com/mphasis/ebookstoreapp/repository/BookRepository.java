package com.mphasis.ebookstoreapp.repository;
 
 
import java.util.List;
 
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
 
import com.mphasis.ebookstoreapp.entity.Book;
 
@Repository
public interface BookRepository extends JpaRepository<Book, Long> {
	List<Book> findAllById(Long id); // Custom: Find by ID
    List<Book> findByBookTitle(String bookTitle); // Custom: Find by Title
    List<Book> findByBookPublisherLike(String bookPublisher); // Custom: Find by Publisher (like)
    List<Book> findByBookYear(Integer bookYear); // Custom: Find by Year
 
}