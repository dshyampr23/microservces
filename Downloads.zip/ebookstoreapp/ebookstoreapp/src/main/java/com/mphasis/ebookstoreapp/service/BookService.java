package com.mphasis.ebookstoreapp.service;
 
import java.util.List;
import java.util.Optional;
 
import com.mphasis.ebookstoreapp.entity.Book;
 
public interface BookService {
	public Book addBook(Book book);
	public Book updateBook(Book book);
	public List<Book> findAllBooks();
	public Optional<Book> findBookById(Long id);
	public void deleteBookById(Long id);
	public List<Book> findByBookTitle(String title);
	public List<Book> findByBookPublisherLike(String publisher);
	public List<Book> findByBookYear(Integer year);
 
}