package com.mphasis.eBookStore_Consumer_Feign_Hystrix.proxy;

import org.springframework.stereotype.Component;
import java.util.List;
import java.util.Collections;

import com.mphasis.eBookStore_Consumer_Feign_Hystrix.model.Book;

@Component  // Register as a Spring Bean
public class BookServiceFallback implements BookServiceProxy {

    @Override
    public Book getBookById(Integer id) {
        // Fallback logic for retrieving a single book by ID
        System.out.println("Fallback triggered: Unable to fetch book by ID " + id);
        return new Book();  // Return an empty book or some default values
    }

    @Override
    public List<Book> getAllBooks() {
        // Fallback logic for retrieving all books
        System.out.println("Fallback triggered: Unable to fetch all books");
        return Collections.emptyList();  // Return an empty list as fallback
    }
}
