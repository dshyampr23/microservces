package com.mphasis.eBookStore_Consumer_Feign_Hystrix.service;

import com.mphasis.eBookStore_Consumer_Feign_Hystrix.model.Book;
import com.mphasis.eBookStore_Consumer_Feign_Hystrix.proxy.BookServiceProxy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    private final BookServiceProxy bookServiceProxy;

    // Constructor-based dependency injection (preferred over field injection)
    @Autowired
    public BookService(BookServiceProxy bookServiceProxy) {
        this.bookServiceProxy = bookServiceProxy;
    }

    /**
     * Fetch a book by its ID from the book-service.
     * 
     * @param id The ID of the book.
     * @return The book object.
     */
    public Book getBookById(Integer id) {
        // Use the Feign client to get the book from the remote service
        return bookServiceProxy.getBookById(id);
    }

    /**
     * Fetch all books from the book-service.
     * 
     * @return A list of books.
     */
    public List<Book> getAllBooks() {
        // Use the Feign client to get the list of all books
        return bookServiceProxy.getAllBooks();
    }
}
