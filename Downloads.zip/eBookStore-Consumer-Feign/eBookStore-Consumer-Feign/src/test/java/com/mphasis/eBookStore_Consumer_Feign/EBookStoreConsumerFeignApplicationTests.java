package com.mphasis.eBookStore_Consumer_Feign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EBookStoreConsumerFeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
