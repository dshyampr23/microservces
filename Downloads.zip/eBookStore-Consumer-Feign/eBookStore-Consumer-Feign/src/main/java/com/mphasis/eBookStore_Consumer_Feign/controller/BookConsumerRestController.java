package com.mphasis.eBookStore_Consumer_Feign.controller;

import com.mphasis.eBookStore_Consumer_Feign.model.Book;
import com.mphasis.eBookStore_Consumer_Feign.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/consumer")
public class BookConsumerRestController {

    private final BookService bookService;

    // Inject BookService (which uses the BookServiceProxy)
    @Autowired
    public BookConsumerRestController(BookService bookService) {
        this.bookService = bookService;
    }

    // Endpoint to get a book by its ID
    @GetMapping("/books/{id}")
    public Book getBookById(@PathVariable Integer id) {
        // Use the BookService to fetch the book by ID
        return bookService.getBookById(id);
    }

    // Endpoint to get all books
    @GetMapping("/books")
    public List<Book> getAllBooks() {
        // Use the BookService to fetch the list of all books
        return bookService.getAllBooks();
    }
}
