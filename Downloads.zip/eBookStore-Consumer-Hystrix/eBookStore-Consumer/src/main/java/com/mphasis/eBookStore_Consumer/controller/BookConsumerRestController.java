package com.mphasis.eBookStore_Consumer.controller;


import java.awt.print.Book;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController
public class BookConsumerRestController {

    @Autowired
    private RestTemplate restTemplate;

    // Endpoint to consume book-service API (e.g., http://book-service/books/1)
    @GetMapping("/get-books/{id}")
    public ResponseEntity<Book> getBookById(@PathVariable("id") Long id) {
        // Direct call to book-service (use the direct URL for now for testing)
        ResponseEntity<Book> response = restTemplate.getForEntity("http://localhost:8080/books/" + id, Book.class);

        // Return the response directly from the call
        return response;
    }
}