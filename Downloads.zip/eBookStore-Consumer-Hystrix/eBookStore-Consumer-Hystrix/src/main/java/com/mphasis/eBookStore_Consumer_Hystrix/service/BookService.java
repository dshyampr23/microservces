package com.mphasis.eBookStore_Consumer_Hystrix.service;

import com.mphasis.eBookStore_Consumer_Hystrix.model.Book;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class BookService {

    private final RestTemplate restTemplate;

    // Constructor-based injection of RestTemplate (make sure RestTemplate is defined as a bean)
    public BookService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    /**
     * This method fetches book details from an external API using RestTemplate.
     * If it fails (e.g., the external service is down), it will trigger the fallback method.
     */
    @HystrixCommand(fallbackMethod = "fallbackForGetBookById")
    public Book getBookById(Integer id) {
        // Make a call to an external service to fetch book details by ID
        String url = "http://book-service/api/books/" + id;
        return restTemplate.getForObject(url, Book.class);
    }

    /**
     * Fallback method for the getBookById method.
     * This method will be invoked if the getBookById method fails.
     * It provides a default response when the external service is unavailable.
     */
    public Book fallbackForGetBookById(Integer bookId, Throwable throwable) {
        // Log the exception (optional)
        System.out.println("Fallback triggered for bookId: " + bookId + " due to: " + throwable.getMessage());
        // Return a default Book object as a fallback
        return new Book(bookId, "Unknown Book", "Unknown Author", 0.0);
    }
}