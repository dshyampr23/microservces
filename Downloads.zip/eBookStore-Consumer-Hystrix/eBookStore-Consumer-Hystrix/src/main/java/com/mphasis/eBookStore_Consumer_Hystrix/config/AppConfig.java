package com.mphasis.eBookStore_Consumer_Hystrix.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

@Configuration  // This class provides configuration for Spring beans
public class AppConfig {

    @Bean  // Expose RestTemplate as a Spring bean for injection into services
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }
}