package com.mphasis.eBookStore_Consumer_Hystrix.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mphasis.eBookStore_Consumer_Hystrix.model.Book;
import com.mphasis.eBookStore_Consumer_Hystrix.service.BookService;

@RestController  // This makes the class a REST controller
public class BookController {
	
	@Autowired
    private BookService bookService;
	
	private static final Logger log = LoggerFactory.getLogger(BookController.class);

    // Autowire the BookService into the controller
    @Autowired
    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    /**
     * Endpoint to fetch book details by bookId.
     * It calls the BookService to fetch the details.
     */
//    @GetMapping("/book/{id}")
//    public String getBookDetails(@PathVariable Integer id) {
//          // Calls the service method
//    }
    
    @GetMapping("/get-books/{id}")
    public Book getBookById(@PathVariable("id") Integer id) {
        log.debug("In getBookById with Id: " + id);
        Book book = bookService.getBookById(id);  // Call the service method to fetch the book by ID
        log.debug("Returning book details: " + book);
        return book;
    }
}