package com.mphasis.eBookStore_Consumer_Hystrix.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import brave.sampler.Sampler;

//import brave.sampler.Sampler;

@Configuration
public class SleuthConfig {

    // Define a bean that always samples (i.e., traces every request)
    @Bean
    public Sampler alwaysSampler() {
        return Sampler.ALWAYS_SAMPLE;  // Ensures that all requests are traced
    }
}
